// 引入工具文件
let file = require('./util/file')

// 👇 核心修改：从命令行参数获取路径
// process.argv[2] 就是 C# 传给 Node.js 的第一个参数
var path = process.argv[2];

// 校验路径是否传入
if (!path) {
    console.log("错误：请传入文件夹路径参数！");
    process.exit(1); // 退出程序
}

file.createUUIDlist(path);
file.replaceUUID(path);


